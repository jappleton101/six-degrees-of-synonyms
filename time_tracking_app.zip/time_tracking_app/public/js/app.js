const successfulStyle = {
    background: "green"
}

const lockedStyle = {
    background: "grey"
}

class PuzzleBoard extends React.Component {
    state = {
        puzzle: {},
        session: {
            inputStatus: ["open", "locked", "locked", "locked", "locked"],
            guesses: []
        },
        currentGuess: "",
        currentNode: "",
        statusMessage: "Start here."
    }

    componentDidMount() {
        this.loadDailyFromServer();
    }

    loadDailyFromServer = () => {
        client.getDaily((dailyPuzzle)=>(
            this.setState({ puzzle: dailyPuzzle })
        ))
    }

    handleRandomButtonClick = () => {
        
        

        client.getRandomPuzzle((randomPuzzle)=>(
            this.setState({ 
                puzzle: randomPuzzle,
                session: {
                    inputStatus: ["open", "locked", "locked", "locked", "locked"],
                    guesses: []
                },
                currentGuess: "",
                currentNode: "",
                statusMessage: "Start here."
            }, function() {
                for(let i = 0; i<5; i++){
                    console.log(document.getElementById("level_"+i))
                    document.getElementById("level_"+i).value = "";
                }
            })
        ))
    }

    handlePuzzleGuessSubmit = (guess, currentNode) => {
        let newState = Object.assign({}, this.state)

        // handleEmpty Guess
        if(!currentNode || guess === ""){
            this.setState({
                session: newState.session,
                statusMessage: "Enter a guess!"
            }, function(){
                console.log("Enter a guess, yo!");
            })
        } else {
            let guessPosition = parseInt(currentNode.split("_").slice(-1));
            let newSession = Object.assign({}, this.state.session)
            
            // handleCorrectGuess
            if(this.state.puzzle.answers[guessPosition].indexOf(guess.toLowerCase()) !== -1){
                newSession.guesses.push(guess);

                const newInputStatus = [...this.state.session.inputStatus];
                newInputStatus[guessPosition] = "correct";

                if(guessPosition !== 4){
                    newInputStatus[guessPosition+1] = "open";   
                } 

                newSession.inputStatus = newInputStatus;

                this.setState({
                    session: newSession,
                    currentGuess: "",
                    statusMessage: "Moving on up!"
                }, function(){
                    console.log("Correct guess!");
                })
            } else {

                let answerField = document.getElementById(currentNode);
                if(this.state.session.guesses.indexOf(guess.toLowerCase()) === -1){
                    // Handle incorrect guess
                    answerField.value = "";
                    newSession.guesses.push(guess);
                    newSession = newState.session;

                    this.setState({
                        session: newSession,
                        currentGuess: "",
                        statusMessage: "'"+ guess+"' was incorrect, try again!"
                    }, function(){
                        console.log("Wrong guess!");
                    })
                } else {
                    // handle duplicate guess
                    answerField.value = "";
                    this.setState({
                        session: newSession,
                        currentGuess: "",
                        statusMessage: "Try something other than, '"+ guess +"'."
                    }, function(){
                        console.log("Duplicate guess!");
                    })
                }
            }
        }
        
            // Old code for Lives instead of guess count
            // newSession.livesRemaining = this.state.session.livesRemaining-1;
            // if(newSession.livesRemaining > 0){
            //     console.log("Try again!");
            //     this.setState({
            //         session: newSession
            //     }, function(){
            //         console.log(this.state);
            //     })
            // } else {
            //     console.log("Game over!");
            //     newSession.inputStatus = ["locked","locked","locked","locked","locked"]
            //     this.setState({
            //         session: newSession
            //     }, function(){
            //         console.log(this.state);
            //     })
            // }
        
    }

    hanldePuzzleGiveUp = (currentNode) => {
        let nodeValue = currentNode;
        let puzzleField = document.getElementById("level_" + nodeValue);
        let giveUpSession = Object.assign({}, this.state.session)

        while(nodeValue <= 4){
            puzzleField = document.getElementById("level_" + nodeValue);
            puzzleField.value = this.state.puzzle.answers[nodeValue];
            giveUpSession.inputStatus[nodeValue] = "locked";
            nodeValue++;
        }

        this.setState({
            session: giveUpSession,
            statusMessage: "Game over!"
        }, function(){
            console.log("Game over!");
        })
    }

    // submitPuzzleGuessToServer = (guess) => {
    //     console.log("Submitting to server...");
    //     console.log(guess);
    // }

    render() {
        return (
            <div className="ui three column centered grid">
                <div className="column">
                    <div className="ui centered card">
                        <div className="content">
                            <StatusBar
                                session={this.state.session}
                            />
                            <PuzzleLadder
                                puzzle={this.state.puzzle}
                                session={this.state.session}
                                onSubmitClick={this.handlePuzzleGuessSubmit}
                                onGiveUpClick={this.hanldePuzzleGiveUp}
                                onRandomClick={this.handleRandomButtonClick}
                                statusMessageProp={this.state.statusMessage}
                            />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

class StatusBar extends React.Component {
    render() {

        // Old code for lives instead of guess count
        // if(this.props.session.guesses.length === 0){
        //     return (
        //         <div className="ui dividing header"> 
        //             {"Better luck next time!"}
        //         </div>
        //     )
        // } 

        // let lifeBubbles = [];
        // let key = "";

        // for(let i = 0; i<this.props.session.livesRemaining; i++){
        //     key = "life_"+i
        //     lifeBubbles.push(<i key={key} className="circle icon"></i>)
        // }

        let emoji = "🧐";
        let guessCount = this.props.session.guesses.length;

        if(this.props.session.inputStatus.lastIndexOf("correct") === 4){
            if(guessCount < 6){
                emoji = "🤩"
            } else if(guessCount < 12){
                emoji = "😊"
            } else if(guessCount < 18){ 
                emoji = "😐"
            } else {
                emoji = "😵"
            }
        } 

        if(this.props.session.inputStatus.indexOf("open")===-1 && this.props.session.inputStatus.lastIndexOf("correct") !== 4){
            emoji = "☠️"
        }

        return (
            <div className="ui dividing header"> 
                {/* {"Lives remaining:   "}
                <br/>
                {lifeBubbles} */}
                {"Guess Count: " + this.props.session.guesses.length}
                <br/>
                {emoji}
            </div>
        )
    }
}

class PuzzleLadder extends React.Component {
    state = {
        
    }

    handleRandomClick = () => {
        this.props.onRandomClick()
    }

    handleGuessChange = (e) => {
        this.setState({
            currentGuess: e.target.value,
            currentNode: e.target.id,
            statusMessage: this.props.statusMessageProp
        })
    }

    handleSubmitClick = () => {
        this.props.onSubmitClick(this.state.currentGuess, this.state.currentNode);
        this.setState({
            currentGuess: "",
            statusMessage: this.props.statusMessageProp
        })
    }

    handleGiveUpClick = () => {
        this.props.onGiveUpClick(this.props.session.inputStatus.indexOf("open"));
    }

    render() {
        if(this.props.puzzle.ladder){
            let puzzleLadder = [];
            let fieldNameId;

            for(let i = this.props.puzzle.ladder.length-2; i>=0; i--){
                fieldNameId = "level_"+i
                puzzleLadder.push(
                <div className="ui segment" key={fieldNameId}>
                    <label className="field">{this.props.puzzle.ladder[i+1]}</label>
                    <br/>
                    <div className="ui left icon input">
                        <input 
                            type="text"
                            id={fieldNameId}
                            onChange={this.handleGuessChange}
                            onSubmit={this.handleSubmitClick}
                            disabled={this.props.session.inputStatus[i] === "open" ? false : true}
                            style={this.props.session.inputStatus[i] === "correct" ? successfulStyle 
                            : this.props.session.inputStatus[i] === "locked" ? lockedStyle : null}
                        />
                        {this.props.session.inputStatus[i] === "open" ? 
                        <p className='ui left pointing basic blue label'>
                            {this.props.session.inputStatus.lastIndexOf("correct") === 4 ? "You win!" : this.props.statusMessageProp}
                        </p> : null}
                        {this.props.session.inputStatus[i] === "correct" ? <i className="check circle icon"/> : 
                            this.props.session.inputStatus[i] === "open" ? <i className="arrow up icon"/> : 
                            <i className="lock icon"/>}
                    </div>
                    <div className="field">
                        <label>{this.props.puzzle.ladder[i]}</label>
                    </div>
                </div>
            );
            }

            return (
                <div className="ui form">
                    <div className="ui segments">
                    {puzzleLadder}
                    </div>
                    <br/>
                    
                    <div className="ui two bottom attached buttons">
                        <button 
                            type="text"
                            className="ui primary blue button"
                            id="guess"
                            onClick={this.handleSubmitClick}
                        >
                            Guess
                        </button>
                    </div>
                    <br/>
                    <div className="ui two bottom attached buttons">
                        <button 
                                type="text"
                                className="ui basic green button"
                                id="hint"
                            >
                                Hint
                        </button>
                        <button 
                            className="ui basic red button"
                            id="giveup"
                            onClick={this.handleGiveUpClick}
                        >
                            Give Up
                        </button>
                    </div>
                    <br/>
                    <div className="ui two bottom attached buttons">
                        <button 
                            type="text"
                            className="ui secondary button"
                            id="random"
                            onClick={this.handleRandomClick}
                        >
                            Random Puzzle
                        </button>
                    </div>
                    
                </div>
            )
        } else {
            return (
                <div className="ui form">
                    <div className="field">
                    Your puzzle is on the way...
                    </div>
                    <br/>
                </div>
            )
        }
    }
}

ReactDOM.render(
    <PuzzleBoard />,
    document.getElementById('content')
)